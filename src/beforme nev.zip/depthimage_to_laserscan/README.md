depthimage_to_laserscan
=======================

Converts a depth image to a laser scan for use with navigation and localization.

ROS Wiki Page:
http://www.ros.org/wiki/depthimage_to_laserscan
