octomap_ros
===========

ROS package to provide conversion functions between ROS and OctoMap's native types.

This repository continues from the groovy branch imported from SVN: 
http://alufr-ros-pkg.googlecode.com/svn/branches/octomap_stacks-groovy-devel/octomap_ros/ 
See https://code.google.com/p/alufr-ros-pkg/ for the previous versions.
